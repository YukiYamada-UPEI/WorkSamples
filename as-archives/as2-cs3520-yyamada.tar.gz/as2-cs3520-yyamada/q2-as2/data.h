#ifndef MDATA
#define MDATA

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>

/* define mutex variable */
pthread_mutex_t* mutexshm;


const int TEST = 1;//change test mode = 1

/* define Shared Memory size */
static const int NMSIZE = 3*sizeof(int); //3 digits

static const int INFOSIZE = 2 + (sizeof(int)+sizeof(int))*3 + sizeof(int);//header(2) + {score(4)+weight(4)}*3 + result(4);
static const int MSIZE = (2 + (sizeof(int)+sizeof(int))*3 + sizeof(int)) * 3; 
 

/* Define the names of the shared memory segments */
static const char *name = "SHMSEQ";
static const char *namen = "SHMSEQnumbers";
static const int Mutexsize=sizeof(pthread_mutex_t);


/* Shared memory file descriptor */
int shm_fd;
int shm_n_fd;
int mutexsegment_id;

/* temporary rewritable string buffer */
char str[128];


#endif
