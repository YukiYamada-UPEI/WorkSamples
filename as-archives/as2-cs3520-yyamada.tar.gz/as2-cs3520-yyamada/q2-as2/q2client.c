#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdbool.h>
#include <stdlib.h>

#include "data.h"



/*shared data within client and its threads*/
int numofscores = 3; //Number of scores to be entered
int scores[3]; //Each score is stored
int weights[3]; //Each score's weight percentage
int size = 0; //Size of scores in scores[]

float multipliedScores[3]; //Each calculated result is stored
int sizeMultipliedScores = 0; //Size of multipliedScores[]


void *runnerRead(void *param); /*Reading thread*/



int main(){
	
    /*pointers used for access to shared memory segment */
    void *ptr,*nptr;
    
    
    /* open the shared memory segment */
    shm_fd = shm_open(name, O_RDWR, 0666);
    if (shm_fd == -1) {
        printf("shared memory failed\n");
        exit(-1);
    }
	shm_n_fd = shm_open(namen, O_RDWR, 0666);
    if (shm_n_fd == -1) {
        printf("shared memory numbers failed\n");
        exit(-1);
    }
    
    
    /* Shared memory segment for the mutex variable */
    mutexsegment_id=shmget(IPC_PRIVATE,Mutexsize, S_IRUSR|S_IWUSR);
    
    
    /* now map the shared memory segment of the buffer in the address space of the process */
    ptr = mmap(0,MSIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd,0);
    if (ptr == MAP_FAILED) {
        printf("Map failed\n");
        exit(-1);
    }
    /* now map the shared memory segment of the number in the address space of the process */
    nptr = mmap(0,NMSIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_n_fd, 0);
    if (nptr == MAP_FAILED) {
        printf("Map failed for number\n");
        exit(-1);
    }
    
    /* now map the shared memory segment of the mutex in the address space of the process */
    mutexshm=(pthread_mutex_t*)shmat(mutexsegment_id,NULL,0);
    
    
  
    /*Check if the server has an avility to process*/
    printf("Client is active\n");
    void *indexptr = nptr;
	printf("indexptr: %d\n", *(int*)(indexptr));

	bool ready = false;
	int sec = 0;
	int spot = 0;
	while(!ready){
		printf("spots= [%d|%d|%d] (%d sec) waiting spot\n",  
									*(int*)nptr, 
									*(int*)(nptr+INFOSIZE),
									*(int*)(nptr+INFOSIZE+INFOSIZE),
									sec);
		if(*(int*)indexptr == 0){
			*(int*)indexptr = 1; //set that to filled
			ready = true;
			printf("Found\n");
		}else{
			sec++;
			spot++;
			if(spot==3){
				indexptr = nptr; 
				spot=0;
				}
			else{
				indexptr += INFOSIZE;
				}
			sleep(1);
		}
	}
	
	void *contentptr;
	
	if(spot == 0){
		contentptr =  ptr;
	}else if(spot == 1){
		contentptr = ptr + INFOSIZE; 
	}else if(spot == 2){
		contentptr = ptr + INFOSIZE + INFOSIZE;
	}	
	
    printf("spot %d\n", spot);
    void *resultptr = contentptr + (sizeof(int) * 6); //pointer to get result


	/*You are now ready for the main task with Threads*/
	printf("Threads start\n");
  
	/*Thread Read*/
	pthread_t tid; 
	pthread_attr_t attr; 
	pthread_attr_init(&attr);
	pthread_create(&tid,&attr,runnerRead, (void*)1);
	
	/*Waits for all the threads to terminate*/
    pthread_join(tid,NULL);
		
	char fst[12];
	char snd[12];
	char thd[12];
	sprintf(fst,"%d", scores[0]);
	sprintf(snd,"%d", scores[1]);
	sprintf(thd,"%d", scores[3]);
	
	char data[250] = "";
		int i;

	for(i=0; i<3; i++){
	    char sco[12];
		sprintf(sco,"%d", scores[i]);
		strcat(data, sco);
		strcat(data, " ");
		
		char wei[12];
		sprintf(wei,"%d", weights[i]);
		strcat(data, wei);
		strcat(data, " ");
	}
	
	
	/*Write the data obtained by a thread into ShM*/
    //strcpy(data, "89  50   99    20 99 30");//test data
    printf("Input: %s\n", data); 
    sprintf(contentptr,"%s",data); //send data into memory
     
    *(int*)indexptr = 2; //data are sent.
	
	
   /*Wait for a server to send back*/
   printf("Waiting for server\n");
   while(*(int*)indexptr != 3 ){
	   sleep(1);
	   printf(".\n");
   }
   
   printf("Result: %.2f%%\n", *(float*)resultptr);
   printf("\n");
   *(int*)indexptr = 4; //Client received the result
   
	/*Countdown for closing*/
	int countdown = 10;
	printf("Closing in %d sec\n",countdown);
	
	while(countdown > 0){
		if(countdown <= 3)
			printf("%d sec\n",countdown);
		countdown--;
		sleep(1);
	}
   
   return 0;
}




/*Thread to accept user's inputs and store them*/
void *runnerRead(void*param)
{
 int score;
 int weight;
 
	int i;
	for(i = 0; i<3; i++){
		printf("[Read Thread:]\n");
		printf("Enter a score (%d/3): ", i+1);
		scanf("%d", &score);
		printf("Enter a weight %% (%d/3): ", i+1);
		scanf("%d", &weight);
		scores[i] = score;
		weights[i] = weight;
		size++; 
	}
 pthread_exit(0);
}



