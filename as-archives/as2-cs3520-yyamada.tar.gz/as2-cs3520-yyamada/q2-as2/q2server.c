#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdbool.h>


#include "data.h"


/*shared data within server and its threads*/
int numofscores = 3; //Number of scores to be entered
int scores[3][3]; //Each score is stored
int weights[3][3]; //Each score's weight percentage
int size[3] = {0, 0, 0}; //Size of scores in scores[]
float result[3]; //Result percentage to send back

float multipliedScores[3][3]; //Each calculated result is stored
int sizeMultipliedScores[3] = {0,0,0}; //Size of multipliedScores[]


void *runnerMultiply(void *param); /*Calculation thread*/
void *runnerCollect(void *param); /*Sum and Print thread*/


int main(){


    /*pointers used for access to shared memory segment */
    void *ptr,*nptr;//global to every child process
    
   
    /* create the shared memory segment */
    shm_fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    shm_n_fd = shm_open(namen, O_CREAT | O_RDWR, 0666);
    
    /* Shared memory segment for the mutex variable */
    mutexsegment_id=shmget(IPC_PRIVATE,Mutexsize, S_IRUSR|S_IWUSR);
    
    /* configure the size of the shared memory segment */
    ftruncate(shm_fd,MSIZE);
    ftruncate(shm_n_fd,sizeof(NMSIZE));
    
    
    /* now map the shared memory segment of the buffer in the address space of the process */
    ptr = mmap(0,MSIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd,0);
    if (ptr == MAP_FAILED) {
        printf("Map failed\n");
        exit(-1);
    }
    /* now map the shared memory segment of the number in the address space of the process */
    nptr = mmap(0,NMSIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_n_fd, 0);
    if (nptr == MAP_FAILED) {
        printf("Map failed for number\n");
        exit(-1);
    }
    
    /* now map the shared memory segment of the mutex in the address space of the process */
    mutexshm=(pthread_mutex_t*)shmat(mutexsegment_id,NULL,0);
    
    
    
    

	/*Initialize the availability shared memory to all 0*/
	void *indexptr = nptr; //indexptr should be unique to each child process
	int j;
	for(j=1;j<4;j++){
		*(int *)indexptr = 0; //three empty spots = 0
		indexptr += INFOSIZE;
	}
	indexptr = nptr;
	printf("Server is ready to accept\n");
	
	/*Just for counting down 3*/
	int repeat = 1;	
	while(repeat){	
			int countdown = 3;
			while(countdown > 0){
				printf("%d\n",countdown);
				countdown--;
				sleep(1);
			}

			/*Accept client. Find 2 (client pending) in any spot*/	
			bool ready = false;
			int sec = 0; //just counts how seconds
			int spotparent = 0;
			while(!ready){
				printf("spots= [%d|%d|%d] (%d sec)\n",  
									*(int*)nptr, 
									*(int*)(nptr+INFOSIZE),
									*(int*)(nptr+INFOSIZE+INFOSIZE),
									sec);
				if(*(int*)indexptr == 1){
					*(int*)indexptr = 11;//no more one child for one client
					ready = true;
					printf("Found[%d]\n", spotparent);//
				}else{
					sec++;
					spotparent++;
					if(spotparent==3){
						indexptr = nptr; 
						spotparent=0;
						}
					else{
						indexptr += INFOSIZE;
						}
					sleep(1);
				}
			}
						
			/*one child process one client*/
			if(fork() == 0){
					/*Decide which spot of the shared memory to use*/
					void *childptr = indexptr;
					while(*(int*)childptr == 11);
					void *contentptr;
					int spot = spotparent;
					
					/*Choose which spot's pointer to use*/
					if(spot == 0){
						contentptr =  ptr;
					}else if(spot == 1){
						contentptr = ptr + INFOSIZE; 
					}else if(spot == 2){
						contentptr = ptr + INFOSIZE + INFOSIZE;
					}			
					void *resultptr = contentptr + (sizeof(int) * 6); //pointer to get result
	
	
					/*You are now ready for the main task with Threads*/
					/*Receive a string of scores and percentages*/
					char data[250];
					sprintf(data, "%s", (char*)contentptr);
					printf("received[%d]: %s\n",spot, data);
					
					/*Take each number from string and store into arrays*/
					int op = 0; //0=score 1=weight
					int i=0;
					char *word;
					word = strtok(data, " ");
					while(word != NULL){
						if(op==0){
							scores[spot][i] = strtol(word, NULL, 10);
							word = strtok(NULL, " ");
							op = 1;
						}else{
							weights[spot][i] = strtol(word, NULL, 10);
							word = strtok(NULL, " ");
							op = 0;
							i++;
							size[spot]++;//how many you have in your memory
						}

					}
					
					/*Thread to sum up results*/
					pthread_t tid3;
					pthread_attr_t attr3; 
					pthread_attr_init(&attr3);
					pthread_create(&tid3,&attr3,runnerCollect,(void*)spot); 
					
					/*Threads tp calculate percentage*/
					int load;
					load = 0;
					while(load < 3){
					   sleep(1);
					   if(size[spot]!= 0){
						 pthread_t tid2;
						 pthread_attr_t attr2; 
						 pthread_attr_init(&attr2);
						 int arr[2] = {spot, load};//the parameter to send to Multiply Thread
						 pthread_create(&tid2,&attr2,runnerMultiply,(void*)arr);
						 size[spot]--;
						 load++;
						 }  
					   }
				
					
				   /*Waits for all the threads to terminate*/
				   pthread_join(tid3,NULL);
				   
				   /*Send info back to client*/
				   printf("result[%d]: %.2f%%\n",spot, result[spot]);
				   *(float*)resultptr = result[spot];
				   *(int*)childptr = 3;
				   
				   while(*(int*)childptr != 4){
					   sleep(1);
				   }
				   *(int*)childptr = 0; //reset the spot to empty again
				   
				   /*A child process finish it work*/
				   printf("Child process[%d] terminates\n",spot);
				   exit(EXIT_SUCCESS);
			       }
			       
			  /*You are parent*/
			  else{
						sleep(1);//sleep one second before going back
						}
		   
			repeat = 1; //terminates
		}//end-while
   
   
   /* remove the shared memory segment */
   if (shm_unlink(name) == -1) {
       printf("Error removing %s\n",name);
       exit(-1);
       }
       
   /*Server terminates*/    
   printf("Server terminates\n");
   return 0;
}





/*Thread to calculate percentage*/
void *runnerMultiply(void*param){	
	int *arr = (int*) param;
	int spot  = (int)arr[0];
	int index = (int)arr[1];
		
	int score = scores[spot][index];
	int weight = weights[spot][index];
	float percent;
	percent = (float)score * (float)weight / 100.0;
	multipliedScores[spot][index] = percent;
	sizeMultipliedScores[spot]++;
	
	pthread_exit(0);

}


/*Thread to collect each calculated value and sum them up, and print results*/
void *runnerCollect(void*param){
	int spot = (int)param;
	float sum = 0; //sum of each calculated scores
	int load = 0; //Index of shared memory
	while(load < 3){
		sleep(1);
		if(sizeMultipliedScores[spot] != 0){
			sum += multipliedScores[spot][load];
			sizeMultipliedScores[spot]--;
			load++;
      		}  
		}
	result[spot] = sum;
 	pthread_exit(0);
}




