#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <stdbool.h>


/*shared data*/
int numofscores = 3; //Number of scores to be entered
int scores[3]; //Each score is stored
int weights[3]; //Each score's weight percentage
int size = 0; //Size of scores in scores[]

float multipliedScores[3]; //Each calculated result is stored
int sizeMultipliedScores = 0; //Size of multipliedScores[]


void *runnerRead(void *param); /*Reading thread*/
void *runnerMultiply(void *param); /*Calculation thread*/
void *runnerCollect(void *param); /*Sum and Print thread*/


int main(){

	printf("\n");
	
  
	/*Thread Read*/
	pthread_t tid; 
	pthread_attr_t attr; 
	pthread_attr_init(&attr);
	pthread_create(&tid,&attr,runnerRead, (void*)1);
	
	/*Thread to sum up results*/
	pthread_t tid3;
	pthread_attr_t attr3; 
	pthread_attr_init(&attr3);
   	pthread_create(&tid3,&attr3,runnerCollect,(void*)0);  
    
	/*Threads tp calculate percentage*/
	int load;
	load = 0;
	while(load < 3){
	   sleep(1);
	   if(size != 0){
		 pthread_t tid2;
		 pthread_attr_t attr2; 
		 pthread_attr_init(&attr2);
         	 pthread_create(&tid2,&attr2,runnerMultiply,(void*)load);
         size--;
         load++;
       }  
    }
    
   /*Waits for all the threads to terminate*/
   pthread_join(tid,NULL);
   pthread_join(tid3,NULL);
   printf("\n");
   
   
	char *done;
	printf("Enter any letter to terminate:");
	scanf("%s", done);

   
   
   return 0;
}




/*Thread to accept user's inputs and store them*/
void *runnerRead(void*param)
{
 int score;
 int weight;
 
	int i;
	for(i = 0; i<3; i++){
		printf("[Read Thread:]\n");
		printf("Enter a score (%d/3): ", i+1);
		scanf("%d", &score);
		printf("Enter a weight %% (%d/3): ", i+1);
		scanf("%d", &weight);
		scores[i] = score;
		weights[i] = weight;
		size++; 
		sleep(2);
	}
 pthread_exit(0);
}


/*Thread to calculate percentage*/
void *runnerMultiply(void*param)
{
	int index = (int)param;
	int score = scores[index];
	int weight = weights[index];
	float percent;
	percent = (float)score * (float)weight / 100;
	multipliedScores[index] = percent;
	sizeMultipliedScores++;

	printf("\n[Calc Thread: Percent%d: %.1f]\n",index+1, percent);
	
	pthread_exit(0);

}


/*Thread to collect each calculated value and sum them up, and print results*/
void *runnerCollect(void*param)
{
	float sum = 0; //sum of each calculated scores
	int load = 0; //Index of shared memory
	while(load < 3){
		sleep(1);
		if(sizeMultipliedScores != 0){
			sum += multipliedScores[load];
			sizeMultipliedScores--;
			load++;
			printf("[Sum Thread: Current sum%d: %.1f]\n\n",load, sum);
      		}  
	}
	printf("<<Sum Thread: Your total grade is %.1f%% >>\n", sum);
 	pthread_exit(0);
}







