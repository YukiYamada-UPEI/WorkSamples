/* Program Create Pipe
 *
 * pipes.c
 */ 
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>

int main() 
{
  char *myfifo = "mFIFO";
  printf("Creating the pipe %s\n",myfifo);
  if (mkfifo(myfifo, S_IRWXU|S_IRWXO) != 0)
    perror("mkfifo() error");
  else
    printf("Fifo %s Created\n",myfifo);
  printf("Fifo %s Exists\n",myfifo);

  char *myfifo2 = "mFIFO2";
  printf("Creating the pipe %s\n",myfifo2);
  if (mkfifo(myfifo2, S_IRWXU|S_IRWXO) != 0)
    perror("mkfifo() error");
  else
    printf("Fifo %s Created\n",myfifo2);
  printf("Fifo %s Exists\n",myfifo2);

  return 0;
}
