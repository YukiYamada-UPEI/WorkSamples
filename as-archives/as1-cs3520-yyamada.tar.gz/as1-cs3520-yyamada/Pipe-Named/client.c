/*Program receive data from mFIFO
 * 
 * ReadPipe.c
 */ 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include<unistd.h>


int pipeout(char* s, int pipe){
 write(pipe,s,strlen(s));
}

int pipein(char* s, int pipe){
 int m=0,i;
 while ((i=read(pipe,s,1))>0){s++,m++;};
 s[m+1]='\0';
 return m;
}


int main() //client
{
  char *myfifo = "mFIFO";
  char *myfifo2 = "mFIFO2";
  char* buffer;
  int m;
  int pipe;
  int pipeSend;



  /*sends score to the server*/
  pipeSend=open(myfifo2,O_WRONLY);
  printf("\nI am the Client\n");
  char *num;
  num = "55";
  printf("Score auto generated: %s\n",num);
  printf("Enter a score: %d\n", atoi(num));
  write(pipeSend, num, sizeof(num));
  close(pipeSend);
  


  /*receives the list from the server and prints it*/
 
  pipe=open(myfifo,O_RDONLY);
  buffer=(char*)malloc(sizeof(char)*1024);
  m=pipein(buffer,pipe);
  printf("I am the Client");
  printf("\n %s\n",buffer);
  close(pipe);


  /*chooses a course and send*/
	pipeSend=open(myfifo2,O_WRONLY);
	char user[10];
	
	strcpy(&user, "math-2420");
	printf("Choice auto-generated: %s\n", user);
	printf("Type a course name: %s\n",user);
	write(pipeSend, &user, strlen(user));
	close(pipeSend);




  //close(pipe);
  //close(pipeSend);
  return 0;
}
