/*Program send data to mFIFO
 * 
 * WritePipe.c
 */ 
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>




FILE* writeToFile(char* str);
void readFromFile(int score, int fd);
void sendMsg(char *str, int fd);





int pipeout(char* s, int pipe){
 write(pipe,s,strlen(s));
}

int pipein(char* s, int pipe){
 int m=0,i;
 while ((i=read(pipe,s,1))>0){s++,m++;};
 s[m+1]='\0';
 return m;
}


int main() //server side
{
  char *myfifo = "mFIFO";
  char *myfifo2 = "mFIFO2";
  char* S="The following string is written to a pipe: ";
  char *buffer;
  int pipe;
  int pipeRecv;
  //pipe=open(myfifo,O_WRONLY);


  //printf("File number %d\n",pipe);
  //printf("File2 number %d\n",pipeRecv);


 /*recieve score to the client*/
 /*=============================*/
  pipeRecv=open(myfifo2, O_RDONLY);
  int num;
  char *str;  
  //char *str1;
  buffer=(char*)malloc(sizeof(char)*1024);
  read(pipeRecv, str, sizeof(str));
  printf("\nI am the Server \nReceive score & send list back\n\n");
  num = atoi(str);
 close(pipeRecv);



 /*send back the list to the client*/
  pipe=open(myfifo,O_WRONLY);
  readFromFile(num, pipe);
  close(pipe);




 /*Receive the choice and create a text file*/
 char str1[50];
  pipeRecv=open(myfifo2, O_RDONLY);
  read(pipeRecv, str1, strlen(str1));

  printf("\n\nI am the Server \nNEXT-course created\n\n");
  writeToFile(str1);
  close(pipeRecv);



/*close pipes*/
  //close(pipe);
  //close(pipeRecv);

  return 0;
}



/*Write to a NEXT text file*/
FILE* writeToFile(char* str){
	FILE* file;
	file = fopen("NEXT-course.txt", "w");
	fprintf(file, "%s\n", str);
	fclose(file);
	return file;
}

/*Gets score and check */
void readFromFile(int score, int fd){
	char str[256];
	FILE* file;
	if(score >= 70){
		file = fopen("list1.txt","r");
	}
	else{
		file = fopen("list2.txt","r");
	}
	char msg[1000] = "==========\n[Course List]\n";
	while(fgets(str, 256, file) != NULL){
		strcat(msg, str);
	}
	strcat(msg,"===========\n");
	sendMsg(msg, fd);
	fclose(file);
}

/*operation for each IPC*/
void sendMsg(char *str, int fd){
	write(fd, str, strlen(str));

}






