
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>
#include <stdbool.h>

#include "file.h"

int main(){
	const int SIZE = 8*4096;
	const int BYTE = 8;
	int interval = 1024;
	const char *name = "SHMSEQ";
	int shm_fd;
	void *ptr, *startptr;
	char str[128];
	
	shm_fd = shm_open(name, O_CREAT | O_RDWR, 0777);


	startptr = ptr = mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

	if(ptr == MAP_FAILED){
		printf("Map failed\n");
		exit(-1);
	}
	

	sleep(1);

	/*Read score from client*/
	char *line = ptr;//reading from shared memory
	int num = atoi(line);


	/*Calculate and read the course list*/
	char *l = readFromFile(num);


	/*Sends the course list*/
	sprintf(ptr, "%s", l);
	printf("\nI am the Server\nreceived: %d \nsending the list\n\n",num);
	sleep(3);
	
	/*Getting selection from the server*/
	sprintf(line, "%s", ptr);
	printf("\nI am the Server\nYour choise: %s\n", line);
	num = atoi(line);
	writeToFile(line);
	printf("Text file is created.\n\n");
	
	
}







