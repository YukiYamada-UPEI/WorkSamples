#ifndef FILE_H
#define FILE_H

FILE* writeToFile(char* str);
char* readFromFile(int score);
void sendMsg(char *str);
void testPrint();



#endif // _FILE_H_
