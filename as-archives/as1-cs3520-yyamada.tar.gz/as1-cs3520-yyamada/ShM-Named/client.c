
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <time.h>
#include <stdbool.h>

int main(){
	const int SIZE = 8*4096;
	int interval = 1024;
	const char *name = "SHMSEQ";
	int shm_fd;
	void *ptr, *startptr;
	char str[128];
	
	shm_fd = shm_open(name, O_CREAT | O_RDWR, 0777);
	ftruncate(shm_fd,SIZE);


	startptr = ptr = mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

	if(ptr == MAP_FAILED){
		printf("Map failed\n");
		exit(-1);
	}

	/*Send score to the server*/
	int score = 78;
	printf("\nI am the Client\nscore auto-generated: %d \nsending \n\n", score);
	sprintf(str, "%d", score);
	sprintf(ptr, "%s", str);
	sleep(2);

	/*Receive list and prints it from server*/
	char line[1000];
 	sprintf(line,"%s", ptr);
	printf("\nI am the Client\n%s", line);
	char* course = "cs4810";
	printf("course auto-selected: %s\n\n",course); 

	/*User selects and sends information back*/
	sprintf(ptr, "%s", course);
	sleep(2);


	
}






