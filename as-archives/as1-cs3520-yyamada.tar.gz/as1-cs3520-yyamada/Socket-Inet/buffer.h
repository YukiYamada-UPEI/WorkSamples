#define MAXsize 30

char bufferin[MAXsize];
char bufferout[MAXsize];

char* readinbuffer(int fd_socket,char* buffer);
