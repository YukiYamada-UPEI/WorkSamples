#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>

#include <unistd.h>
#include "buffer.h"

int main(int argc, char* argv[])
{
	int fd_socket; 
	int len;
	struct sockaddr_in address;
	int result;
	char strcha[MAXsize];

	/* create socket for client*/
	fd_socket=socket(AF_INET, SOCK_STREAM, 0);

	/* Name the socket */
	address.sin_family=AF_INET;
	address.sin_addr.s_addr=inet_addr("127.0.0.1");
	address.sin_port=9110;
	len=sizeof(address);
	
	sleep(1);
	/* Connect client to server socket*/
	result=connect(fd_socket, (struct sockaddr *)&address,len);
	if (result ==-1)
	{
		perror("client");
		exit(1);
	}

	/*communicate with server*/
        int StillActive=4;
        
	while (StillActive>0)
	{
		
		if(StillActive == 4){
		 printf("\n\nI am client\n Enter a score:");
         scanf("%s",bufferout);
		 write(fd_socket,bufferout,strlen(bufferout)+1);
         //printf("waiting for server...\n");
         StillActive--;
			
		}else if(StillActive ==3){
		 readinbuffer(fd_socket,bufferin);
		 printf("\n\nI am client\n printing list:\n");
		 printf("%s/\n",bufferin);
		 StillActive--;
		 
		}else if(StillActive ==2){
		 printf("Type the course name you choose:");
         scanf("%s",bufferout);
		 write(fd_socket,bufferout,strlen(bufferout)+1);
		 StillActive=0;
		}
		
		
         //printf("Stop condition 0=%d\n",StillActive); 
	}
       	close(fd_socket);
	exit(0);

}
