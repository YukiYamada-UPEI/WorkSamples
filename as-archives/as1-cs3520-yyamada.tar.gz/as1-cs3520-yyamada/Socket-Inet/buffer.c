#include <string.h>
#include <stdio.h>


void readinbuffer(int fd_socket,char* buffer)
{
 int j=0;
 char * bufferpos;
 bufferpos=buffer-1;
// printf("[%d] starting positions %x,%x",fd_socket,bufferpos,buffer);
        do
         {
          bufferpos++;
		  read(fd_socket,bufferpos,1);
          if (*bufferpos){
			  //printf(" [%d]=%c,%c ",j,*bufferpos,*(buffer+j));}
		 }
          j++;
         }
        while (*bufferpos);
   //printf("%d Buffercontent:/%s/\n",strlen(buffer),buffer);

 return;
}
