#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "buffer.h"
#include "file.h"


int main(int argc, char* argv[])
{
 int fd_server_socket; 
 int fd_client_socket; 
 int server_len;
 int client_len;
 int i,n; 

 struct sockaddr_in server_address;
 struct sockaddr_in client_address;
 
 /* create an unnamed socket*/
 fd_server_socket=socket(AF_INET, SOCK_STREAM, 0);
 
 /* Name the socket */
 server_address.sin_family=AF_INET;
 server_address.sin_addr.s_addr=inet_addr("127.0.0.1");
 server_address.sin_port=9110;
 server_len=sizeof(server_address);
 bind(fd_server_socket,(struct sockaddr*)& server_address,server_len);

 /* create a connection queue and wait for clients */
 listen(fd_server_socket,15);
 while (1)
      {
	
	printf("server waiting\n");

	/* accept connection*/
        client_len=sizeof(client_address);
        fd_client_socket = accept(fd_server_socket,(struct sockaddr *)&client_address,&client_len);
	
	/* communicate with client*/
        printf("Communication started s:%d, c:%d \n",fd_server_socket,fd_client_socket);
	
	int order = 4;
	  while(order>0)
	  {
		
		if(order==4){
			readinbuffer(fd_client_socket,bufferin);
			printf("\n\nI am server\nreceiving\n");
			printf("%s\n",bufferin);
			int a = atoi(bufferin);
			strcpy(bufferout, readFromFile(a));
			//printf("sending\n");
			order--;
        
			
		}else if(order==3){    
			
			write(fd_client_socket,&bufferout,strlen(bufferout)+1);	
			printf("reading and sending list\n");
			order--;
			
		}else if(order==2){    
			readinbuffer(fd_client_socket,bufferin);
			n=strlen(bufferin);
			printf("\n\nI am server\nreceiving choice\n");
			printf("your choice:%s\n",bufferin);
			printf("NEXT-course.txt created.\n\n\n");
			writeToFile(bufferin);
			order=0;
		}
		
			

        if(!strcasecmp(bufferin,"stop"))break;
	 }
    if(!strcmp(bufferin,"STOP") || order == 0)break;
  }
	close(fd_client_socket);
 exit(0);

}
