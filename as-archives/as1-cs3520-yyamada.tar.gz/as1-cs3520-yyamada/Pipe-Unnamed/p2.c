#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "file.h";


#define SIZE 1024
#define NofMess 4

int status;
int main () {
    int fdpc[2]; /*--pipe parent --> child read=0, write=1 write to parent not allowed */
    int fdcp[2]; /*--pipe child --> parent read=0, write=1 read from parent not allowed */
    int nread;
    int pid;
    int i=0;
    char buf1 [SIZE];
    char buf2 [SIZE];

    if (pipe(fdpc) == -1)  {
        perror("pipe failed");
        exit(1);
    }
   
    if (pipe(fdcp) == -1)  {
        perror("pipe failed");
        exit(1);
    }
   
    if ((pid = fork()) < 0)  {
        perror("fork failed");
        exit(2);
    }  

 if (pid == 0)  {    	/* child - Client */
        printf("Child process %d\n",getpid()); 
        close(fdpc[1]);  /* Close write end for fdpc parent-->Child */
        close(fdcp[0]);  /* Close read end for fdcp Child-->parent */
       
        strcpy(buf2, "88"); //send a score;
        printf("\nI am Clinet\nScore auto-generated: %s\nEnter score: %s\n", buf2, buf2);

        sleep(1);
        write(fdcp[1],buf2, SIZE);
        sleep(1);
        
        read(fdpc[0], buf1, SIZE);
        printf("\nI am Clinet\n%s", buf1); //prints list
        char *course = "mcs-4210";
	printf("course choice auto-generated: %s\nsending\n\n", course);

        strcpy(buf2, course);
        write(fdcp[1],buf2, SIZE);


             
        sleep(1);
        close(fdpc[0]);
       close(fdcp[1]);
        printf("child will terminate soon\n");
        
        
    } else {    	/* parent - Server*/
        printf("Parent process %d\n",getpid()); 
        close(fdpc[0]);    	/* close read end parent ->child*/
        close(fdcp[1]);    	/* close write end child->parent*/

        sleep(2);
        
        read(fdcp[0], buf2, SIZE);
        printf("\nI am Server\nI received: %s\nsending list\n\n", buf2);
        strcpy(buf1, readFromFile(atoi(buf2))); //Get the list

        write(fdpc[1], buf1, SIZE);
        sleep(1);

	printf("I am Server\nNEXT-course created\n\n\n");
	read(fdcp[0], buf2, SIZE);
	writeToFile(buf2);
 
        sleep(1);
        close(fdpc[1]);
        close(fdcp[0]);
        printf("Wait for child to terminate!\n");
        int childPID=wait(&status);        
        printf("child with pid %d terminated with exit code %d\n",childPID, status>>8);
    }
    printf("Both execute this line %d\n",getpid());
    exit(0);

}
