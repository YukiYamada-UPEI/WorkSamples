#include <stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#include "file.h"

int main()
{
 /* the identifier for the shared memory segment */
int segment_id;

/*  a pointer to the shared memory segment */
char * shared_memory;

/* the syze in bytes of the shared memory segment */
const int size=4096;

/* allocate a shared memory segment*/
segment_id=shmget(IPC_PRIVATE, size, S_IRUSR| S_IWUSR);
// printf("Segment Id=%d\n",segment_id);

/* attach the shared memory segment */
shared_memory=(char*)shmat(segment_id, NULL,0);

printf("Shared memory pointer=%x\n",shared_memory);


int SHIFT = 10;
char* head = shared_memory;
char* msgpointer = shared_memory + SHIFT;//shift to the pointer to the real message



int pid,childPID,status;
pid=fork();
if (pid!=0) /* parent server */
   {
    char buffer[1024];

    printf("Shared memory pointer=%x\n",shared_memory);

    int a =1;
    char *start=shared_memory;
	
	/*Waiting for score*/
     a = 1;
     while(a){
		// printf("Server witing...\n");
		 sleep(1);
		 sscanf(start, "%s", buffer);
		 if(!strcmp(buffer, "server")){
			 a = 0;
		 }
	 }

	 /*Read score from SM*/
	 printf("\n\nI am server\nreading score & sending list\n");

	 sscanf(msgpointer, "%s", buffer);
	 
	 /*Write list to SM*/
	 char *l = readFromFile(atoi(buffer));
	 sprintf(msgpointer, l);
	 sprintf(shared_memory, "client");
	 
	 
	 /*Waiting for the choice*/
	 a=1;
	 while(a){
		 //printf("Server witing...\n");
		 sleep(1);
		 sscanf(start, "%s", buffer);
		 if(!strcmp(buffer, "server")){
			 a = 0;
		 }
	 }
	 
	 
	 /*Read choice from SM*/
	 printf("\n\nI am server\ncreating NEXT-course text file\n\n");
	 writeToFile(msgpointer);
	 
     
     wait(NULL);
     
 }else{ /*child client*/
  
    char bufferC[1024];
    
    /*Write score to SM*/
    printf("\n\nI am client\nsending score\n");
    printf("Enter a score: ");
    scanf("%s", bufferC);
    printf(bufferC);
    sprintf(msgpointer, bufferC);
    sprintf(shared_memory, "server");

     /*Wait for the list*/
     int b = 1;
     while(b){
		 sleep(1);
		 sscanf(head, "%s", bufferC);
		 if(!strcmp(bufferC, "client")){
			 b = 0;
		 }
	 }
	 
	 /*Read list from SM*/
	 printf("\n\nI am client\nprinting list\n");
	 	 printf("%s\n",msgpointer);

	 int hasLine = 1;
	 char *temp = msgpointer;
	 
	 /*Write choice to SM*/
	 printf("Type a course name: ");
	 scanf("%s", bufferC);
	 sprintf(msgpointer,"%s", bufferC);
	 sprintf(shared_memory, "%s", "server");
    }
 
  shmdt(shared_memory);

  /* now remove the shared memory segment*/
  shmctl(segment_id,IPC_RMID,NULL);
  return 0;
}
