#include <stdio.h>
#include <string.h>
#include "file.h"


void testPrint(){
printf("THIS IS TEST");
}

/*Write to a NEXT text file*/
FILE* writeToFile(char* str){
	FILE* file;
	file = fopen("NEXT-course.txt", "w");
	fprintf(file, "%s\n", str);
	fclose(file);
	return file;
}

/*Gets score and check */
char* readFromFile(int score){
	char str[256];
	FILE* file;
	if(score >= 70){
		file = fopen("list1.txt","r");
	}
	else{
		file = fopen("list2.txt","r");
	}
	char msg[1000] = "=============\n[CourseList]\n";
	while(fgets(str, 256, file) != NULL){
		strcat(msg, str);
	}
	strcat(msg,"=============\n");
	fclose(file);
	return msg;
}

/*operation for each IPC*/
void sendMsg(char *str){
	printf("%s",str);
}





























///
