#include "communication.h"


void writeToSocket(int fd, char* message)
{
	
	int chw;
	chw=write(fd,message,strlen(message)+1);
	//printf("chars written to socket %d\n",chw);
	
	
}



char* readSocket(int fd)
{
	char* str;
	int m=0;
        str=(char*)malloc(sizeof(char)*256);
	str[0]=0x32;
        int l;
        ////printf("buffer address: %x\n",str);
	while(readline(fd,str,&m)&&str[0])
             {
                //printf("reading:%d chars are:",m); 
		//printf("%s, %x\n",str,str[0]); /* echo from socket*/
             }
         //printf("%d characters read.. end of communication\n",m);
  return str;
}

int readline(int fd, char* str,int *m)
{
	int n;
        //printf("%d\n",fd);
	do
	{
		n=read(fd,str,1);
                //printf("%d Errno=%d\n", n, errno); // Used for debugging
                if (errno) {n=0; break;}
                  
		(*m)++;
                //printf("read %d character %c,%x at address %x\n",n,*str,*str,str);
                str++;
	}
	while((n>0) && (*(str-1) != 0));
        //printf("reading from %d finished\n",fd);
	return (n>0);
}

int readIntFromSocket(int fd)
{
	
	int m;
        //pm=(int*) malloc(sizeof(int));
        int l;
        //printf("buffer address: %x\n",&m);
        l=read(fd,&m,sizeof(int));
	//printf("%d bytes read number %d, end of communication\n",l,m);
 return m;
}

void writeIntToSocket(int fd, int x)
{
	int chw;
	chw=write(fd,&x,sizeof(x));
	//printf("%d Bytes written to socket %d\n",chw,x);
	
	
}
