#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>


#define DEFAULT_PROTOCOL 0

void writeToSocket(int fd,char*);
char* readSocket(int fd);
int readline(int fd, char* str,int *m);
void writeIntToSocket(int fd, int x);
int readIntFromSocket(int fd);

