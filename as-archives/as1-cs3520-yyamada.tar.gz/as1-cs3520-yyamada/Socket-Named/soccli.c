

#include "communication.h"


int main(int argc, char* argv[])
{

	int fd_client, fd_server, serverln,result;
	struct sockaddr_un serverUNIXAddress;
	struct sockaddr* serverSockAddrPtr;
	
	serverSockAddrPtr=(struct sockaddr*)&serverUNIXAddress;
	serverln=sizeof(serverUNIXAddress);

        int x,y;


        fd_client= socket (AF_UNIX,SOCK_STREAM, DEFAULT_PROTOCOL);
	serverUNIXAddress.sun_family= AF_UNIX;
	strcpy(serverUNIXAddress.sun_path,"sockServ1");
        char *buffer; 

	/*loop until connection is establised with the server*/ 
       do{
	       result=connect(fd_client,serverSockAddrPtr,serverln);
	       if (result<0)         //(result==-1) 
                    {
                      sleep(1);
                      //printf("client trying to connect  again...\n"); 
                    }

       }
       while (result<0);//(result ==-1);
       //printf("Connection Established %d %d\n ... reading data from server ..\n",fd_client,result);

	/*Send score to the server*/
	printf("\n-I am the Client-(1)\nSending score\n\n");
	int score = 44;
	writeIntToSocket(fd_client, score);
	sleep(1);
	

	/*Receive list from server*/
	buffer = readSocket(fd_client);
	printf("\n-I am the Client-(2)\n");
	printf("%s\n",buffer);


	/*Send the choice to the server*/
	/*
	char *c; 
	c = "math-2420";
	writeToSocket(fd_client, c);
	sleep(1);
	*/

       close(fd_client);
       printf("Client will now terminate\n");
       exit(EXIT_SUCCESS);
}


