

#include "communication.h"
#include "file.h"


int main(int argc, char* argv[])
{
 int fd_server, fd_client, serverln,clientln;
 struct sockaddr_un serverUNIXAddress;
 struct sockaddr_un clientUNIXAddress;
 struct sockaddr*   serverSockAddrPtr;
 struct sockaddr*   clientSockAddrPtr;
 int status;
 int errcode;
 int x,y;
 
 /* ignore death of a child signals to prevent zombies*/
 signal(SIGCHLD,SIG_IGN); 
 /* This will set errno to 10, when child process finishes */


 serverSockAddrPtr=(struct sockaddr*)&serverUNIXAddress;
 serverln = sizeof(serverUNIXAddress);

 clientSockAddrPtr=(struct sockaddr*)&clientUNIXAddress;
 clientln = sizeof(clientUNIXAddress);
 
 /* create unix socket, bidirectional, default */
 fd_server = socket(AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);
 //printf("Server File Number = %d\n",fd_server);
 serverUNIXAddress.sun_family = AF_UNIX;
 /* domain trype = AF_UNIX */
 /* set name*/
 strcpy(serverUNIXAddress.sun_path, "sockServ1");
 unlink("sockServ1"); /* remove if it exists */
 /* creates file */
 errcode=bind(fd_server, serverSockAddrPtr,serverln);
 /* the pending connection length(queue length) is 5 */
 errcode=listen (fd_server,5);
 clientln=sizeof(clientSockAddrPtr);
 while (1)
      {
	      /* accept a client connection */
	      do{
		      //printf("Server tries to accept a client connection...\n");
		      fd_client = accept(fd_server,clientSockAddrPtr,&clientln);
		      //printf("Errno=%d\n", errno);
		      //printf("fd_client = %d\n",fd_client); 
	      }
	      while (fd_client<0);//end do-while
	      //printf(" Accepted Client with File Number =%d\n",fd_client);

		/*Child process*/
	      if (fork() ==0){
		sleep(1);



		/*Receive a score*/
		int score = readIntFromSocket(fd_client);
		printf("\n-I am the Server-(1)\n"
		"Received score: %d\nSending list\n\n", score);

		/*Read the list*/
		char *l = readFromFile(score);
		printf("\n");

		/*Send the list back*/
		writeToSocket(fd_client, l);
		sleep(1);

		/*Receive the choice*/
		//char *choice = readSocket(fd_client);
		//printf("-I am the Server-(2)\n");
		writeToFile("math-2420");
		//printf("File created\n");
		
		

		/*close socket*/
	       close(fd_client); 
	       exit(EXIT_SUCCESS);


		/*Parent process*/
	      }else{
	       int childPID=wait(&status);
	       close(fd_client); /* close client descriptor */
              
	      }
      }	      
 return 0;
}



